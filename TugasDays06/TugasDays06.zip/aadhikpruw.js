let sekolah = "purwadhika"
let splitsekolah = sekolah.split("")
console.log(splitsekolah.sort().join(""))
