let str1 = "waw"
let str1split = str1.split("")
console.log(str1split.reverse())
let str1join = str1split.join("")
if(str1 == str1join) {
    console.log(true)
} else {
    console.log(false)
}

let str2 = "ibu"
let str2split = str2.split("")
console.log(str2split.reverse())
let str2join = str2split.join("")
if(str2 == str2join) {
    console.log(true)
} else {
    console.log(false)
}
